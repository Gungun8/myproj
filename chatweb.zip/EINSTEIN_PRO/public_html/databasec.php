<?php
// Database connection
$hostname = "localhost"; // Assuming the database is hosted locally
$username = "root"; // Your MySQL username (default is "root" for localhost)
$password = ""; // Your MySQL password (default is empty for localhost)
$database = "my_db"; // Your MySQL database name

$conn = mysqli_connect($hostname, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Form submission handling
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST['username'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $password = $_POST['password'];
    $retype_password = $_POST['retype_password'];
    
    // Check if passwords match
    if ($password != $retype_password) {
        echo "Passwords do not match.";
    } else {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // SQL query to insert user data into database
        $sql = "INSERT INTO users (username, email, gender, password) VALUES ('$username', '$email', '$gender', '$hashed_password')";
        
        if (mysqli_query($conn, $sql)) {
            echo "Signup successful!";
            // Redirect to login page or any other page after successful signup
            header("Location: login.php");
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
    
    // Close database connection
    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sign Up</title>
</head>
<body>
    <h2>Sign Up</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        Username: <input type="text" name="username" required><br><br>
        Email: <input type="email" name="email" required><br><br>
        Gender:
        <input type="radio" name="gender" value="male" checked> Male
        <input type="radio" name="gender" value="female"> Female<br><br>
        Password: <input type="password" name="password" required><br><br>
        Retype Password: <input type="password" name="retype_password" required><br><br>
        <input type="submit" value="Sign Up">
    </form>
</body>
</html>
