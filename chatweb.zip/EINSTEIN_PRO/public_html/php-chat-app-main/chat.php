
<?php 
  session_start();

  if (isset($_SESSION['username'])) {
  	# database connection file
  	include 'app/db.conn.php';

  	include 'app/helpers/user.php';
  	include 'app/helpers/chat.php';
  	include 'app/helpers/opened.php';

  	include 'app/helpers/timeAgo.php';

  	if (!isset($_GET['user'])) {
  		header("Location: home.php");
  		exit;
  	}
# Getting User data data
$user = getUser($_SESSION['username'], $conn);

  	# Getting User data data
  	$chatWith = getUser($_GET['user'], $conn);

  	if (empty($chatWith)) {
  		header("Location: home.php");
  		exit;
  	}

  	$chats = getChats($_SESSION['user_id'], $chatWith['user_id'], $conn);

  	opened($chatWith['user_id'], $conn, $chats);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Chat App</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<link rel="stylesheet" 
	      href="css/style.css">
	<link rel="icon" href="img/logo.png">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style>
		#wrapper{

max-width:1200px;

max-height: 690px;
display:flex;
margin: auto;
color: white;
font-family: myFont;
font-size: 13px;
margin-top: 40px;
margin-bottom: 10px;
border-top: 5px solid white;
border-right: 2.5px solid white;
box-shadow: 0px 0px 6px 4px rgba(0, 0, 0, 0.5);
}

#left_pannel{

min-height: 600px;
min-width: 300px;
background-color: #0b132b;
flex: 1;
text-align: center;
border: solid;
border-bottom: 7px solid white;

}

#profile_image{

width: 50%;
border: solid thin black;
border-radius: 50%;
margin-left:53px;
padding: 3px;
box-shadow: 0px 0px 5px 3px rgba(0, 0, 0, 0.5);
border: 2px solid white;


}

#left_pannel label{
font-size: 18px;
width: 100%;
height: 35px;
display: block;
background-color: #000000;
border-bottom:solid thin #ffffff55;
cursor: pointer;
padding: 8px;
transition: all 1s ease;
}

#left_pannel label:hover{

background-color: #8d99ae;
}

#left_pannel label img{

float: right;
width:25px;
}
#right_pannel{

min-height: 180px;
min-width: 100px;
flex: 5;
text-align: center;
}

#header{
min-height: 80px;

background-color: #1c2541;
height:70px;
font-size: 50px;
text-align: center;
font-family: headFont;
position: relative;
}


#chatContainer {
            height: 70px;
			margin-bottom: 20px;
            overflow-y: scroll;
            border: 1px solid #ccc;
            padding: 10px;
            background-color: #ddd;
        }
        #messageInput {
			font-size: 18px;
            width: 20%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
			margin-bottom: 20px;
        }
        
        #languageSelect{
            font-size: 15px;
            padding: 10px;
            margin-bottom: 20px;
        }
        #sendBtn1 {
            font-size:12px;
            padding: 10px 20px;
            cursor: pointer;
            background-color:#000080;
            color: #fff;
            border: none;
            border-radius: 5px;
			margin-bottom: 20px;
        }
        .sentMessage {
            color: blue; /* Display sent messages in blue color */
        }
        .translatedMessageContainer {
            background-color: #ccc; /* Gray background for translated message container */
            padding: 10px;
            overflow-y: auto;
            max-height: 50px; 
			margin-bottom: 18px;/* Limit container height for scroll */
        }
        .translatedMessage {
            margin-bottom: 15px;
        }
		#sendBtn {
            padding: 10px 20px;
            cursor: pointer;
            background-color:#000080;
            color: #fff;
            border: none;
            border-radius: 5px;
            
			margin-bottom: 20px;
        }
		#message{
            border-radius: 5px;
          
           margin-bottom: 20px;
		   font-size:20px;
        }
        #right-header{
            background-color: #1c2541;
        }
        #back-btn{
            color: #ffffff;
            align-items: left;
            font-size: 7px;
        }
        
		
</style>
<body>
<div id="wrapper">
		
		<div id="left_pannel">
        <a href="home.php" id="back-btn" 
    	   class="fs-4 link-dark">&#8592; <b></b></a>

			<div id="user_info" style="padding: 10px;">
			<div   class="d-flex
    			            ">
    			    <img id="profile_image" src="uploads/<?=$user['p_p']?>"
    			         >
						 <br>
                   
    			</div>
				<br>
				<span id ="username " style="font-size: 20px;"><?=$user['name']?></span> <br>
				
				<span id="bio" style="font-size:12px;">Hey there! i'm using Let's Chatt</span>
				
				<br>
				<br>
				<br>
				<div>
					
					
					<a href="logout.php"><label id="logout" for="radio_logout"  style="color:#ffffff">Logout <img src="ui/icons/logout.png"></label></a>
				</div>

			</div>

		</div>	
		<div id="right_pannel">
		
        

    	   <div id= "right-header"class="d-flex align-items-center ">
           <img src="uploads/<?=$chatWith['p_p']?>"
    	   	       class="w-15 rounded-circle">

               <h3 class="display-4 fs-sm m-2">
               	  <?=$chatWith['name']?> <br>
               	  <div class="d-flex
               	              align-items-center"
               	        title="online">
               	    <?php
                        if (last_seen($chatWith['last_seen']) == "Active") {
               	    ?>
               	        <div class="online"></div>
               	        <small class="d-block p-1">Online</small>
               	  	<?php }else{ ?>
               	         <small class="d-block p-1">
               	         	Last seen:
               	         	<?=last_seen($chatWith['last_seen'])?>
               	         </small>
               	  	<?php } ?>
               	  </div>
               </h3>
    	   </div>
			

    	   <div class="shadow p-4 rounded
    	               d-flex flex-column
    	               mt-2 chat-box "
    	        id="chatBox" style="font-size:20px" >
    	        <?php 
                     if (!empty($chats)) {
                     foreach($chats as $chat){
                     	if($chat['from_id'] == $_SESSION['user_id'])
                     	{ ?>
						<p  id ="sender_box" class="rtext align-self-end
                        border rounded p-2 mb-1" >
						    <?=$chat['message']?> 
						    <small class="d-block">
						    	<?=$chat['created_at']?>
                                
						    </small>      	
						</p>
                    <?php }else{ ?>
					<p class="ltext border 
					         rounded p-2 mb-1" >
					    <?=$chat['message']?> 
					    <small class="d-block">
					    	<?=$chat['created_at']?>
					    </small>      	
					</p>
                    <?php } 
                     }	
    	        }else{ ?>
               <div class="alert alert-info 
    				            text-center">
				   <i class="fa fa-comments d-block fs-big"></i>
	               No messages yet, Start the conversation
			   </div>
    	   	<?php } ?>
    	   </div>
    	   <div  class="input-group mb-3 ">
		   <textarea cols="3"
    	   	             id="message"
    	   	             class="form-control"></textarea>
    	   	   <button class="btn btn-primary"
    	   	           id="sendBtn">
    	   	   	  <i class="fa fa-paper-plane"></i>
    	   	   </button>

				  <div id="chatContainer"></div>

    <textarea id="messageInput" placeholder="Translate your message here"></textarea>

    <select id="languageSelect">
        <option value="en">English</option>
        <option value="es">Spanish</option>
        <option value="fr">French</option>
        <option value="gu-IN">Gujarati</option>
        <option value="hi-IN">Hindi</option>
        <option value="ja-JP">Japanese</option>
        <option value="kn-IN">Kannada</option>
        <option value="ko-KR">Korean</option>
        <option value="	kok-IN">Konkani</option>
        <option value="mr-IN">Marathi</option>
        <option value="ru-RU">Russian</option>
        <option value="sa-IN">Sanskrit</option>
        <option value="ta-IN">Tamil</option>
        <option value="te-IN">Telugu</option>
        <option value="zh">Chinese</option>
       

        <!-- Add more language options as needed -->
    </select>

    <button id="sendBtn1" onclick="translateMessage()">T/N</button>
    	   </div>

		</div>
   </div>
    </div>
 

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
	
	

	var scrollDown = function(){
        let chatBox = document.getElementById('chatBox');
        chatBox.scrollTop = chatBox.scrollHeight;
	}

	scrollDown();

	$(document).ready(function(){
      
      $("#sendBtn").on('click', function(){
      	message = $("#message").val();
      	if (message == "") return;

      	$.post("app/ajax/insert.php",
      		   {
      		   	message: message,
      		   	to_id: <?=$chatWith['user_id']?>
      		   },
      		   function(data, status){
                  $("#message").val("");
                  $("#chatBox").append(data);
                  scrollDown();
      		   });
      });

      /** 
      auto update last seen 
      for logged in user
      **/
      let lastSeenUpdate = function(){
      	$.get("app/ajax/update_last_seen.php");
      }
      lastSeenUpdate();
      /** 
      auto update last seen 
      every 10 sec
      **/
      setInterval(lastSeenUpdate, 10000);



      // auto refresh / reload
      let fechData = function(){
      	$.post("app/ajax/getMessage.php", 
      		   {
      		   	id_2: <?=$chatWith['user_id']?>
      		   },
      		   function(data, status){
                  $("#chatBox").append(data);
                  if (data != "") scrollDown();
      		    });
      }

      fechData();
      /** 
      auto update last seen 
      every 0.5 sec
      **/
      setInterval(fechData, 500);
    
    });

	  
      </script>
	  <script>





		 var scrollDown = function(){
        let chatBox = document.getElementById('chatBox');
        chatBox.scrollTop = chatBox.scrollHeight;
	}

	scrollDown();

	$(document).ready(function(){
      
      $("#sendBtn1").on('click', function(){
      	message = $("#messageInput").val();
      	if (messageInput == "") return;

      	$.post("app/ajax/insert.php",
      		   {
      		   	messageInput: messageInput,
      		   	to_id: <?=$chatWith['user_id']?>
      		   },
      		   function(data, status){
                  $("#messageInput").val("");
                  $("#chatBox").append(data);
                  scrollDown();
      		   });
      });

/** 
      auto update last seen 
      for logged in user
      **/
      let lastSeenUpdate = function(){
      	$.get("app/ajax/update_last_seen.php");
      }
      lastSeenUpdate();
      /** 
      auto update last seen 
      every 10 sec
      **/
      setInterval(lastSeenUpdate, 10000);



      // auto refresh / reload
      let fechData = function(){
      	$.post("app/ajax/getMessage.php", 
      		   {
      		   	id_2: <?=$chatWith['user_id']?>
      		   },
      		   function(data, status){
                  $("#chatBox").append(data);
                  if (data != "") scrollDown();
      		    });
      }

      fechData();
      /** 
      auto update last seen 
      every 0.5 sec
      **/
      setInterval(fechData, 500);
    
    });

	
    </script>
	<!-- Google Translate API Script -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        function translateMessage() {
            const apiKey = 'AIzaSyDD_lLvryHRkPoCTyJpjNe9ocCXvN8Tl7w'; // Paste your Google API key here
            const messageInput = document.getElementById('messageInput');
            const targetLanguage = document.getElementById('languageSelect').value;
            const message = messageInput.value.trim();

            if (message === '') {
                alert('Please enter a message to translate.');
                return;
            }

            const apiUrl = `https://translation.googleapis.com/language/translate/v2?key=${apiKey}`;

            $.ajax({
                url: apiUrl,
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({
                    q: message,
                    target: targetLanguage
                }),
                success: function(response) {
                    const translatedText = response.data.translations[0].translatedText;
                    displayTranslatedMessage(message, translatedText);
                },
                error: function(error) {
                    console.error('Translation Error:', error);
                }
            });

            // Clear message input after translation
            messageInput.value = '';
        }

        function displayTranslatedMessage(originalMessage, translatedMessage) {
            const chatContainer = document.getElementById('chatContainer');
            const translatedMessageContainer = document.createElement('div');
            translatedMessageContainer.classList.add('translatedMessageContainer');
            
            const translatedMessageElement = document.createElement('div');
            translatedMessageElement.classList.add('translatedMessage');
            translatedMessageElement.textContent = translatedMessage;
            
            translatedMessageContainer.appendChild(translatedMessageElement);
            chatContainer.appendChild(translatedMessageContainer);

            // Scroll to the bottom of chatContainer
            chatContainer.scrollTop = chatContainer.scrollHeight;
        }
    </script>
 </body>
 </html>
<?php
  }else{
  	header("Location: index.php");
   	exit;
  }
 ?>





