<?php 
  session_start();

  if (isset($_SESSION['username'])) {
  	# database connection file
  	include 'app/db.conn.php';

  	include 'app/helpers/user.php';
  	include 'app/helpers/conversations.php';
    include 'app/helpers/timeAgo.php';
    include 'app/helpers/last_chat.php';

  	# Getting User data data
  	$user = getUser($_SESSION['username'], $conn);

  	# Getting User conversations
  	$conversations = getConversation($user['user_id'], $conn);

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Chat App - Home</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<link rel="stylesheet" 
	      href="css/style.css">
	<link rel="icon" href="img/logo.png">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style>
	#wrapper{

max-width:1000px;
min-height: 500px;
max-height: 680px;
display:flex;
margin: auto;
color: white;
font-family: myFont;
font-size: 13px;
margin-top: 40px;
border-top: 5px solid white;
border-right: 2.5px solid white;
box-shadow: 0px 0px 6px 4px rgba(0, 0, 0, 0.5);
}

#left_pannel{

min-height: 600px;
min-width: 300px;
background-color: #0b132b;
flex: 1;
text-align: center;
border: solid;
border-bottom: 7px solid white;

}

#profile_image{

width: 50%;
border: solid thin black;
border-radius: 50%;
margin-left:53px;
padding: 3px;
box-shadow: 0px 0px 5px 3px rgba(0, 0, 0, 0.5);
border: 2px solid white;


}

#left_pannel label{
font-size: 18px;
width: 100%;
height: 35px;
display: block;
background-color: #000000;
border-bottom:solid thin #ffffff55;
cursor: pointer;
padding: 8px;
transition: all 1s ease;
}

#left_pannel label:hover{

background-color: #8d99ae;
}

#left_pannel label img{

float: right;
width:25px;
}
#right_pannel{

min-height: 500px;
min-width: 200px;
flex: 5;
text-align: center;
}

#header{
min-height: 80px;

background-color: #1c2541;
height:70px;
font-size: 50px;
text-align: center;
font-family: headFont;
position: relative;
}

</style>
<body> 
<div id="wrapper">
		
		<div id="left_pannel">

			<div id="user_info" style="padding: 10px;">
			<div   class="d-flex
    			            ">
    			    <img id="profile_image" src="uploads/<?=$user['p_p']?>"
    			         >
						 <br>
                   
    			</div>
				<br>
				<span id ="username " style="font-size: 20px;"><?=$user['name']?></span> <br>
				
				<span id="bio" style="font-size:12px;">Hey there! i'm using Let's Chatt</span>
				
				<br>
				<br>
				<br>
				<div>
					
					
					<a href="logout.php"><label id="logout" for="radio_logout"  style="color:#ffffff">Logout <img src="ui/icons/logout.png"></label></a>
				</div>

			</div>

		</div>	
		<div id="right_pannel">
			<div id="header">
				
				Let's Chatt
				
			</div>
			
		 
	
    		<div class="d-flex
    		            mb-3 p-3 bg-light
			            justify-content-between
			            align-items-center">
						<div class="d-flex
    			            align-items-center">
							
    			</div>
    			
    		</div>

    		<div class="input-group mb-3">
    			<input type="text"
    			       placeholder="Search..."
    			       id="searchText"
    			       class="form-control">
    			<button class="btn btn-primary" 
    			        id="serachBtn">
    			        <i class="fa fa-search"></i>	
    			</button>       
    		</div>
    		<ul id="chatList"
    		    class="list-group mvh-50 overflow-auto">
    			<?php if (!empty($conversations)) { ?>
    			    <?php 

    			    foreach ($conversations as $conversation){ ?>
	    			<li class="list-group-item">
	    				<a href="chat.php?user=<?=$conversation['username']?>"
	    				   class="d-flex
	    				          justify-content-between
	    				          align-items-center p-2">
	    					<div class="d-flex
	    					            align-items-center">
	    					    <img src="uploads/<?=$conversation['p_p']?>"
	    					         class="w-10 rounded-circle">
	    					    <h3 class="fs-xs m-2">
	    					    	<?=$conversation['name']?><br>
                      <small>
                        <?php 
                          echo lastChat($_SESSION['user_id'], $conversation['user_id'], $conn);
                        ?>
                      </small>
	    					    </h3>            	
	    					</div>
	    					<?php if (last_seen($conversation['last_seen']) == "Active") { ?>
		    					<div title="online">
		    						<div class="online"></div>
		    					</div>
	    					<?php } ?>
	    				</a>
	    			</li>
    			    <?php } ?>
    			<?php }else{ ?>
    				<div class="alert alert-info 
    				            text-center">
					   <i class="fa fa-comments d-block fs-big"></i>
                       No messages yet, Start the conversation
					</div>
    			<?php } ?>
    		</ul>
    	</div>
    </div>
	</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
	$(document).ready(function(){
      
      // Search
       $("#searchText").on("input", function(){
       	 var searchText = $(this).val();
         if(searchText == "") return;
         $.post('app/ajax/search.php', 
         	     {
         	     	key: searchText
         	     },
         	   function(data, status){
                  $("#chatList").html(data);
         	   });
       });

       // Search using the button
       $("#serachBtn").on("click", function(){
       	 var searchText = $("#searchText").val();
         if(searchText == "") return;
         $.post('app/ajax/search.php', 
         	     {
         	     	key: searchText
         	     },
         	   function(data, status){
                  $("#chatList").html(data);
         	   });
       });


      /** 
      auto update last seen 
      for logged in user
      **/
      let lastSeenUpdate = function(){
      	$.get("app/ajax/update_last_seen.php");
      }
      lastSeenUpdate();
      /** 
      auto update last seen 
      every 10 sec
      **/
      setInterval(lastSeenUpdate, 10000);

    });
</script>
</body>
</html>
<?php
  }else{
  	header("Location: index.php");
   	exit;
  }
 ?>